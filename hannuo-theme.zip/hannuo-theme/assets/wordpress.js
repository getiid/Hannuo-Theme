import{k as s}from"./index.js";const t=s.create({baseURL:"https://www.hannuocm.com/wp-json/wp/v2"}),a=()=>t.get("/pages"),e=()=>t.get("/product");export{e as a,a as g};
