<?php
// 在文件开头添加
define('JWT_AUTH_SECRET_KEY', 'your-secret-key');
define('JWT_AUTH_CORS_ENABLE', true);

// 修改CORS设置
function add_cors_headers() {
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // 缓存1天
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
        }
        
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
        }
        exit(0);
    }
}
add_action('init', 'add_cors_headers');

// 添加REST API调试
function debug_rest_api($result, $server, $request) {
    if (is_wp_error($result)) {
        error_log('REST API Error: ' . $result->get_error_message());
    }
    return $result;
}
add_filter('rest_pre_dispatch', 'debug_rest_api', 10, 3);

// 确保REST API可用
function ensure_rest_api() {
    // 移除任何可能禁用REST API的过滤器
    remove_filter('rest_enabled', '__return_false');
    remove_filter('rest_jsonp_enabled', '__return_false');
    
    // 添加基本认证支持
    add_filter('rest_authentication_errors', function($result) {
        if (!empty($result)) {
            return $result;
        }
        if (!is_user_logged_in()) {
            return true;
        }
        return $result;
    });
}
add_action('init', 'ensure_rest_api');

// 添加REST API支持
add_action('rest_api_init', function() {
    remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
}, 15);

// 修改自定义REST API返回字段函数
function custom_rest_prepare_post($data, $post, $request) {
    $_data = $data->data;
    
    // 添加特色图片URL
    if (has_post_thumbnail($post->ID)) {
        $_data['featured_image'] = get_the_post_thumbnail_url($post->ID, 'full');
    }
    
    // 添加文章分类
    $_data['categories_info'] = get_the_category($post->ID);
    
    // 添加ACF字段
    if (function_exists('get_fields')) {
        $_data['acf'] = get_fields($post->ID);
    }
    
    // 添加额外的文章信息
    $_data['author_name'] = get_the_author_meta('display_name', $post->post_author);
    $_data['formatted_date'] = get_the_date('Y-m-d', $post->ID);
    
    $data->data = $_data;
    return $data;
}
add_filter('rest_prepare_post', 'custom_rest_prepare_post', 10, 3);

// 注册自定义文章类型（如果需要）
function register_custom_post_types() {
    register_post_type('products', array(
        'labels' => array(
            'name' => '产品',
            'singular_name' => '产品'
        ),
        'public' => true,
        'show_in_rest' => true, // 确保在REST API中可用
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'has_archive' => true
    ));
}
add_action('init', 'register_custom_post_types');

// 注册自定义分类法（如果需要）
function register_custom_taxonomies() {
    register_taxonomy('product_category', 'products', array(
        'labels' => array(
            'name' => '产品分类',
            'singular_name' => '产品分类'
        ),
        'hierarchical' => true,
        'show_in_rest' => true, // 确保在REST API中可用
    ));
}
add_action('init', 'register_custom_taxonomies');

// 添加缩略图支持
add_theme_support('post-thumbnails');

// 自定义API端点（如果需要）
function register_custom_api_routes() {
    register_rest_route('hannuo/v1', '/featured-products', array(
        'methods' => 'GET',
        'callback' => 'get_featured_products',
        'permission_callback' => '__return_true'
    ));
}
add_action('rest_api_init', 'register_custom_api_routes');

// 修改特色产品函数
function get_featured_products() {
    $args = array(
        'post_type' => 'products',
        'posts_per_page' => 6,
        'meta_query' => array(
            array(
                'key' => 'featured',  // ACF字段名
                'value' => true,
                'compare' => '='
            )
        )
    );
    
    $posts = get_posts($args);
    $data = array();
    
    foreach ($posts as $post) {
        $item = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'featured_image' => get_the_post_thumbnail_url($post->ID, 'full'),
            'acf' => get_fields($post->ID)  // 获取所有ACF字段
        );
        
        $data[] = $item;
    }
    
    return $data;
}

// 在之前的代码后添加
function hannuo_enqueue_scripts() {
    if (WP_ENV === 'development') {
        // 开发环境使用 Vite 开发服务器
        wp_enqueue_script('vite-client', 'http://localhost:5173/@vite/client', array(), null, true);
        wp_enqueue_script('hannuo-main', 'http://localhost:5173/src/main.js', array(), null, true);
    } else {
        // 生产环境使用构建后的文件
        $manifest_path = get_template_directory() . '/dist/manifest.json';
        if (file_exists($manifest_path)) {
            $manifest = json_decode(file_get_contents($manifest_path), true);
            
            // 加载主JS文件
            wp_enqueue_script(
                'hannuo-main',
                get_template_directory_uri() . '/dist/' . $manifest['src/main.js']['file'],
                array(),
                null,
                true
            );

            // 加载CSS文件
            if (isset($manifest['src/main.js']['css'])) {
                foreach ($manifest['src/main.js']['css'] as $css) {
                    wp_enqueue_style(
                        'hannuo-style-' . basename($css),
                        get_template_directory_uri() . '/dist/' . $css
                    );
                }
            }
        }
    }
}
add_action('wp_enqueue_scripts', 'hannuo_enqueue_scripts');

// 添加主题支持
function hannuo_theme_support() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
}
add_action('after_setup_theme', 'hannuo_theme_support');

// 添加REST API调试
add_action('rest_api_init', function() {
    error_log('REST API initialized');
});

add_filter('rest_pre_dispatch', function($result, $server, $request) {
    error_log('REST API Request: ' . $request->get_route());
    return $result;
}, 10, 3);

// 确保ACF字段在REST API中可用
function add_acf_to_rest_api() {
    if (function_exists('acf_get_field_groups')) {
        $field_groups = acf_get_field_groups();
        foreach ($field_groups as $field_group) {
            $fields = acf_get_fields($field_group);
            foreach ($fields as $field) {
                register_rest_field(
                    $field_group['location'][0][0]['param'],
                    $field['name'],
                    array(
                        'get_callback' => function($object) use ($field) {
                            return get_field($field['name'], $object['id']);
                        }
                    )
                );
            }
        }
    }
}
add_action('rest_api_init', 'add_acf_to_rest_api');